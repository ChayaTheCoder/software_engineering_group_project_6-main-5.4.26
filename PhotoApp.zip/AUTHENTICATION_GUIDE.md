# Photo App - Authentication & User Management Guide

## Overview
The backend now supports user authentication with session-based login. Users must have a login_name and password to access the application.

## Database Schema Changes

### User Schema
The User model now includes authentication fields:
```
{
  _id: ObjectId,
  first_name: String,
  last_name: String,
  location: String,
  description: String,
  occupation: String,
  login_name: String (unique, lowercase),
  password: String (hashed with bcrypt)
}
```

### Photo Schema
Photos now have proper relationships:
```
{
  _id: ObjectId,
  file_name: String,
  date_time: Date,
  user_id: ObjectId (reference to User),
  comments: [
    {
      comment: String,
      date_time: Date,
      user_id: ObjectId (reference to User)
    }
  ]
}
```

## API Endpoints

### Authentication Endpoints

#### 1. User Login
**POST /admin/login**
```json
Request:
{
  "login_name": "malcolm",
  "password": "weak"
}

Response (200):
{
  "_id": "...",
  "first_name": "Ian",
  "last_name": "Malcolm",
  "login_name": "malcolm",
  "location": "Austin, TX",
  "description": "Should've stayed in the car.",
  "occupation": "Mathematician"
}
```
- Establishes a session (session cookie is set in response)
- User password hashed with bcrypt, only hash stored in database

#### 2. User Logout
**POST /admin/logout**
- Destroys user session
- No request body needed
```json
Response (200):
{
  "message": "Logged out successfully"
}
```

#### 3. Get Current User
**GET /admin/me**
- Returns currently logged-in user (requires active session)
```json
Response (200):
{
  "_id": "...",
  "first_name": "Ian",
  "last_name": "Malcolm",
  "login_name": "malcolm",
  ...
}

Response (401):
{
  "error": "Not logged in"
}
```

#### 4. Register New User
**POST /user**
```json
Request:
{
  "first_name": "John",
  "last_name": "Doe",
  "login_name": "johndoe",
  "password": "securepassword",
  "location": "San Francisco, CA",
  "description": "Software Developer",
  "occupation": "Engineer"
}

Response (201):
{
  "_id": "...",
  "first_name": "John",
  "last_name": "Doe",
  "login_name": "johndoe",
  ...
}
```
- Password is hashed before storage
- login_name must be unique and is stored in lowercase

### Existing Endpoints

#### User Endpoints
- **GET /user/list** - List all users (basic info only)
- **GET /user/:id** - Get user details (excludes password)

#### Photo Endpoints
- **GET /photosOfUser/:id** - Get all photos for a user with comments

#### Test Endpoints
- **GET /test/info** - Get schema info
- **GET /test/counts** - Get collection counts

## Initial Test Data

When `loadDatabase.js` is run, it creates 6 test users:

| Name | login_name | password |
|------|-----------|----------|
| Ian Malcolm | malcolm | weak |
| Ellen Ripley | ripley | weak |
| Peregrin Took | took | weak |
| Rey Kenobi | kenobi | weak |
| April Ludgate | ludgate | weak |
| John Ousterhout | ousterhout | weak |

## Session Management

- Uses `express-session` for session storage
- Session secret: `"ThisIsTheSecretKeyForDEV"`
- Sessions are HTTP-only cookies (secure by default)
- Current implementation stores sessions in memory (suitable for development)

## Security Features

1. **Password Hashing**: All passwords are hashed using bcrypt (10 salt rounds)
2. **Session Management**: Secure session-based authentication
3. **Login Name Uniqueness**: Prevents duplicate accounts
4. **Case Insensitive Login**: login_name stored and compared in lowercase
5. **Password Protection**: Passwords excluded from API responses

## Running the Application

1. **Load test data:**
   ```bash
   node loadDatabase.js
   ```

2. **Start the server:**
   ```bash
   node webServer.js
   ```

3. **Server runs on:** http://localhost:3000

## Frontend Integration

The frontend can now:
- Display login/register forms
- Send credentials to `/admin/login` and `/admin/logout`
- Use `/admin/me` to check if user is logged in
- Maintain session via cookies (automatic with fetch/axios)
- Use session info to personalize the UI

## Error Handling

Common error responses:
- **400**: Missing required fields or invalid user data
- **401**: Invalid login credentials or not logged in
- **500**: Server error

## Next Steps

To fully integrate authentication in the frontend:
1. Create login/register React components
2. Use `/admin/me` to check auth status on app load
3. Protect routes based on login status
4. Show user info in header/navbar
5. Add logout functionality
