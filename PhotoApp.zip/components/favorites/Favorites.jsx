import React from "react";
import { Button, ImageListItem } from "@mui/material";
import fetchModel from "../../lib/fetchModelData";

class Favorites extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      photos: []
    };
  }

  componentDidMount() {
    this.loadFavorites();
  }

  loadFavorites = () => {
    const userId = this.props.loggedInUser._id;

    fetchModel(`/favorites/${userId}`)
      .then((response) => {
        this.setState({ photos: response.data });
      })
      .catch((err) => {
        console.error("Error loading favorites:", err);
      });
  };

  handleRemove = async (photoId) => {
    try {
      await fetch(`/favorites/remove/${photoId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });

      this.loadFavorites(); // refresh list
      this.props.refreshUser(); // refresh user favorites in parent
    } catch (err) {
      console.error("Error removing favorite:", err);
    }
  };

  render() {
    const { photos } = this.state;

    if (!this.props.loggedInUser) {
      return <div>Please log in to view favorites.</div>;
    }

    // BUG FIX: Check if loggedInUser._id exists before calling loadFavorites
    if (!this.props.loggedInUser._id && photos.length === 0) {
      return <div>Unable to load favorites - invalid user ID.</div>;
    }

    return (
      <div>
        <h2>Your Favorites</h2>

        {photos.length === 0 ? (
          <div>You have no favorite photos yet.</div>
        ) : (
          photos.map((photo) => (
            <div key={photo._id} style={{ marginBottom: "20px" }}>
              <ImageListItem>
                <img
                  src={`images/${photo.file_name}`}
                  alt={photo.file_name}
                  style={{ width: "300px", borderRadius: "8px" }}
                />
              </ImageListItem>

              <Button
                variant="contained"
                color="error"
                onClick={() => this.handleRemove(photo._id)}
                style={{ marginTop: "10px" }}
              >
                Remove Favorite
              </Button>
            </div>
          ))
        )}
      </div>
    );
  }
}

export default Favorites;

